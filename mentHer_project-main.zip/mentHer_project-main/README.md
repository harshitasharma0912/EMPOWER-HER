# mentHer_project
 Platform to support women entrepreneurs with mentorship, funding info, and government schemes

## Project Overview
This project aims to create a platform for mentorship, connecting users with mentors for guidance in various fields.

## Tech Stack
- React
- Node.js
- Express
- MySQL

## Team Members
- Ananta
- Harshita
- Sanjana

## Feature Distribution
- User Authentication
- Entrepreneur Profile
- Mentor Profile
- Matching System
